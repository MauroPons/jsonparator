package various

import (
	"bufio"
	"bytes"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"
)

var (
	basePath           = "/Users/mpons/Documents/comparator/payment-methods/v2/MLB/MLB-POINT-WEEK-25to31/"
	nameFile           = "MLB-POINT-25to31"
	arrayCallerId      []string
	xAuthTokenCallerID = "e484149f5678298f757ebbcfce0155535d61016493d9e567d48e2ae22ff84159"
)

func main() {
	pathCsvFileParamsSorted := fmt.Sprintf("%s/%s.csv", basePath, nameFile)
	pathCsvFileCallerIdEndingInNumber := fmt.Sprintf("%s/666-callerid.csv", basePath)
	pathCsvFileWithoutCallerId := fmt.Sprintf("%s/%s-withouth-callerid.csv", basePath, nameFile)

	fileToParamsSorted, err := os.Open(pathCsvFileParamsSorted)
	if err != nil {
		panic("Can not read fileToSave: " + pathCsvFileParamsSorted)
	}

	saveFileByCallerId(pathCsvFileCallerIdEndingInNumber, pathCsvFileWithoutCallerId, fileToParamsSorted)
	//refreshMpcByCallerIdInReadV2()

	fmt.Println("Finish")
}

func refreshMpcByCallerIdInReadV2() {
	total := len(arrayCallerId)
	fmt.Println("\nTotal CallerId: ", total)

	client := &http.Client{}
	jsonBody := `{"msg": {"site_id":"MLB", "seller_id":%s}}`
	url := "https://testing-synchronizer-contingency_payment-methods-read-v2.furyapps.io/v2/payment-methods/refresh"

	velocityRPSCallerId := 60000 / 1000
	limiterCallerID := time.Tick(time.Duration(velocityRPSCallerId) * time.Millisecond)

	var wg sync.WaitGroup

	for index := range arrayCallerId {
		<-limiterCallerID
		wg.Add(1)
		fmt.Printf("\033[2K\r%d/%d", index, total)
		go func() {
			defer wg.Done()
			callerId := arrayCallerId[index]
			jsonBodyCallerId := []byte(fmt.Sprintf(jsonBody, callerId))
			request, _ := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(jsonBodyCallerId))
			request.Header.Set("Content-Type", "application/json")
			request.Header.Set("X-Auth-Token", xAuthTokenCallerID)
			request.Header.Set("X-Caller-Scopes", "admin")

			resp, err := client.Do(request)
			if err != nil {
				panic(err)
			}

			//body, _ := ioutil.ReadAll(resp.Body)
			//fmt.Println(resp.StatusCode, " - ", callerId, " - response:", string(body))

			resp.Body.Close()
		}()
	}
	wg.Wait()
}

func saveFileByCallerId(pathPatternWithCallerId string, pathPatternWithoutCallerId string, pFile *os.File) {
	numbers := []string{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"}
	mapFilesWithCallerId := make(map[string]*os.File)
	mapCallerId := make(map[string]bool)
	_, _ = pFile.Seek(0, 0)
	scanner := bufio.NewScanner(pFile)
	file, err := os.Create(pathPatternWithoutCallerId)
	if err != nil {
		panic("saveFileByCallerId 0: " + pathPatternWithoutCallerId)
	}
	defer file.Close()

	for scanner.Scan() {
		request := scanner.Text()
		urlValue, err := url.Parse(request)
		if err != nil {
			panic("saveFileByCallerId: " + request)
		}
		callerId := urlValue.Query().Get("caller.id")
		if callerId != "" {
			mapCallerId[callerId] = true
			for i := range numbers {
				if strings.HasSuffix(callerId, numbers[i]) {
					// separar por archivo
					fileTemp := mapFilesWithCallerId[numbers[i]]
					if fileTemp == nil {
						name := strings.Replace(pathPatternWithCallerId, "666", numbers[i], 1)
						fileTemp, err = os.Create(name)
						if err != nil {
							panic("saveFileByCallerId 2: " + request)
						}
					}
					fileTemp.WriteString(request + "\n")
					mapFilesWithCallerId[numbers[i]] = fileTemp
					break
				}
			}
		} else {
			// separar archivo sin caller id
			file.WriteString(request + "\n")
		}
	}

	for i := range numbers {
		fileTemp := mapFilesWithCallerId[numbers[i]]
		if fileTemp != nil {
			totalLine := getTotalRows(fileTemp.Name())
			fmt.Println("File saved caller id ending in ", numbers[i], ":", totalLine, " requests")
		}
	}

	totalLine := getTotalRows(file.Name())
	fmt.Println("File saved no caller id: ", totalLine, " lines")

	for k, _ := range mapCallerId {
		arrayCallerId = append(arrayCallerId, k)
	}
	mapFilesWithCallerId = nil
}

func getTotalRows(pathFile string) string {
	out, err := exec.Command("/bin/sh", "-c", fmt.Sprintf("wc -l %s", pathFile)).CombinedOutput()

	if err != nil {
		panic("getTotalRows - " + pathFile)
	}

	result := strings.Trim(string(out), " ")
	countTemp := strings.Split(result, " ")[0]
	count := strings.TrimSuffix(countTemp, "\n")

	return count
}
