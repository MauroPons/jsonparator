package various

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"strings"
	"time"
)

var (
	pathBaseSE          = "/Users/mpons/Downloads/"
	xCallerScopes       = "online-payments/"
	folderSE            = "20210212202202/"
	pathCsvFullData     = pathBaseSE + "MLB-Week-04_10-no-payer-id-NONE.csv"
	pathCsvError        = pathBaseSE + xCallerScopes + folderSE + "total-error.csv"
	pathCsvFinalPattern = pathBaseSE + xCallerScopes + folderSE + "MLB-Week-04_10-no-payer-id-NONE-%s.csv"
	mapRequests         = make(map[string]bool)
)

func main() {

	initTime := time.Now()

	totalRowsFullData := getTotalRowsInCsv(pathCsvFullData)
	totalRowsError := getTotalRowsInCsv(pathCsvError)
	pathCsvFinal := fmt.Sprintf(pathCsvFinalPattern, totalRowsError)

	fmt.Println(fmt.Sprintf("\n%s %s", totalRowsFullData, pathCsvFullData))
	fmt.Println(fmt.Sprintf("%s: %s", totalRowsError, pathCsvError))

	//grep -f fileFull-error.txt -v -F -x fileFull-full.txt > fileFull-summary.txt
	//exec.Command("/bin/sh", "-c", fmt.Sprintf("grep -vf %s -v -F -x %s > %s", pathCsvError, pathCsvFullData, pathCsvFiltered)).CombinedOutput()

	//exec.Command("/bin/sh", "-c", fmt.Sprintf("cat %s > %s", pathCsvError, pathCsvFinal)).CombinedOutput()

	fileFull, err := os.Open(pathCsvFullData)
	if err != nil {
		panic("Can not read fileFull: " + pathCsvFullData)
	}

	fileFinal, err := os.Create(pathCsvFinal)
	if err != nil {
		panic("Can not read fileFull: " + pathCsvFinal)
	}

	loadRequestsInMap(fileFinal)

	countTotal := 0
	countError := 0
	scanner := bufio.NewScanner(fileFull)

	for scanner.Scan() {
		countTotal++
		request := scanner.Text()
		if !mapRequests[request] {
			fileFinal.WriteString(request + "\n")
		} else {
			countError++
		}
		fmt.Printf("\033[2K\rrequest deleted: %d/%d", countError, countTotal)
	}

	fileFull.Close()
	fileFinal.Close()

	totalRowsFinal := getTotalRowsInCsv(pathCsvFinal)
	fmt.Println(fmt.Sprintf("\n%s %s", totalRowsFinal, pathCsvFinal))

	fmt.Println("Finish - Duration: ", time.Now().Sub(initTime))
}

func loadRequestsInMap(fileFinal *os.File) {
	file, err := os.Open(pathCsvError)
	if err != nil {
		panic("Can not read file: " + pathCsvError)
	}
	_, _ = file.Seek(0, 0)

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		request := scanner.Text()
		fileFinal.WriteString(request + "\n")
		mapRequests[request] = true
	}

	defer file.Close()
}

func getTotalRowsInCsv(pathFile string) string {
	out, err := exec.Command("/bin/sh", "-c", fmt.Sprintf("wc -l %s", pathFile)).CombinedOutput()

	if err != nil {
		panic("getTotalRowsInFile - " + pathFile)
	}

	result := strings.Trim(string(out), " ")
	countTemp := strings.Split(result, " ")[0]
	count := strings.TrimSuffix(countTemp, "\n")

	return count
}
