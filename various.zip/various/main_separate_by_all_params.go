package various

import (
	"bufio"
	"fmt"
	"net/url"
	"os"
	"sort"
)

var (
	basePathParamAllParams       = "/Users/mpons/Downloads/"
	nameFileParamAllParams       = "MLB-Week-04_10-sin-payer-id-errors-37818"
	csvFileAllParams             = fmt.Sprintf("%s/%s.csv", basePathParamAllParams, nameFileParamAllParams)
	pathParamDirectoryAllParams  = fmt.Sprintf("%s/%s", basePathParamAllParams, "all_params")
	pathParamSummaryAllParams    = fmt.Sprintf("%s/summary-all-params.csv", pathParamDirectoryAllParams)
	mapCountFileByParamAllParams = make(map[string]int)
)

func main() {
	if _, err := os.Stat(pathParamDirectoryAllParams); os.IsNotExist(err) {
		os.Mkdir(pathParamDirectoryAllParams, 0777)
	}

	saveFileByParamsAllParams()
	arrayParams := make([]string, 0, len(mapCountFileByParamAllParams))
	for name := range mapCountFileByParamAllParams {
		arrayParams = append(arrayParams, name)
	}

	sort.Slice(arrayParams, func(i, j int) bool {
		return mapCountFileByParamAllParams[arrayParams[i]] > mapCountFileByParamAllParams[arrayParams[j]]
	})

	fileSummary, err := os.Create(pathParamSummaryAllParams)
	if err != nil {
		panic("summary")
	}

	for _, name := range arrayParams {
		msg := fmt.Sprintf("%d - %s", mapCountFileByParamAllParams[name], name)
		fileSummary.WriteString(msg + "\n")
		fmt.Println(msg)
	}
	fileSummary.Close()

	fmt.Println("Finish")
}

func saveFileByParamsAllParams() {
	fileCsv, _ := os.Open(csvFileAllParams)
	_, _ = fileCsv.Seek(0, 0)
	scanner := bufio.NewScanner(fileCsv)

	for scanner.Scan() {
		request := scanner.Text()
		urlValue, err := url.Parse("http://localhost:8080" + request)
		if err != nil {
			panic("saveFileByParams: " + request)
		}

		values := urlValue.Query()
		for keyParam, _ := range values {
			paramTemp := urlValue.Query().Get(keyParam)
			if paramTemp != "" {
				count := mapCountFileByParamAllParams[keyParam]
				count++
				mapCountFileByParamAllParams[keyParam] = count
			}
		}
	}
}
