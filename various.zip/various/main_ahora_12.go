package various

import (
	"bufio"
	"fmt"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

var (
	//basePathSync = "/Users/mpons/Downloads/point/1_error_MLB-POINT-25to31-20210306011247/"
	//initLimit = 385466
	//nameFileSync = "1_error_MLB-POINT-25to31"

	basePathSync2 = "/Users/mpons/Downloads"
	initLimit2    = 0
	nameFileSync2 = "userId_schemaRelIdAll_delete_fix"

	arrayCallerIdSync2      []string
	xAuthTokenCallerIDSync2 = "77a519c48c6c30ac22894bf2e728bba9a7d732bcfc30b448fc901c64639f0d48"
	rpm2                    = 5000
)

func main() {
	pathCsvFileParamsSorted2 := fmt.Sprintf("%s/%s.csv", basePathSync2, nameFileSync2)

	fileToParamsSorted, err := os.Open(pathCsvFileParamsSorted2)
	if err != nil {
		panic("Can not read fileToSave: " + pathCsvFileParamsSorted2)
	}

	syncByCallerId2(fileToParamsSorted)
	fmt.Println("\nFinish")
}

func syncByCallerId2(pFile *os.File) {

	_, _ = pFile.Seek(0, 0)
	scanner := bufio.NewScanner(pFile)

	velocityRPSCallerId := 60000 / rpm2
	limiterCallerID := time.Tick(time.Duration(velocityRPSCallerId) * time.Millisecond)

	var wg sync.WaitGroup

	client := &http.Client{}
	//jsonBody := `{"date": "2021-04-05T00:00:00.000-04:00", "operation": "DEACTIVATE", "sellers": [%s]}`
	url := "https://write_mpcs-differential-pricing.furyapps.io/users/%s/deduction_schema/%s?caller.id=%s"

	index := 1
	for scanner.Scan() {
		<-limiterCallerID
		//fmt.Printf("\033[2K\r%d/%d", index, 14456)
		textLine := scanner.Text()
		textSplit := strings.Split(textLine, ",")
		urlFinal := fmt.Sprintf(url, textSplit[0], textSplit[1], textSplit[0])
		//jsonBodyCallerId := []byte(fmt.Sprintf(jsonBody, textLine))
		wg.Add(1)
		go func() {
			defer wg.Done()
			request, _ := http.NewRequest(http.MethodDelete, urlFinal, nil)
			request.Header.Set("Content-Type", "application/json")
			request.Header.Set("X-Auth-Token", xAuthTokenCallerIDSync2)

			resp, err := client.Do(request)
			if err != nil {
				panic(err)
			}

			if resp.StatusCode == 401 {
				panic("Update X-Auth-Token")
			}

			fmt.Println(index, "/", 14456, " - ", resp.StatusCode, " - ", textLine)
			index++
			resp.Body.Close()
		}()
	}
}
