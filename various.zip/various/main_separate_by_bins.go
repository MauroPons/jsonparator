package various

import (
	"bufio"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"
)

var (
	basePathBins     = "/Users/mpons/Downloads/0-1M/"
	nameFileBins     = "results.#.owner"
	arrayBins        []string
	arrayBinsNotSync []string
	xAuthTokenBins   = "d92f8b2f52a02e96d314fd658fa76bbbcea40cb1eeb5b4e5d12757839780ba63"
	urlBin           = "https://internal-api.mercadopago.com/binapi/v1/search/%s/%s?with=default"
)

func main() {
	pathCsvFileParamsSorted := fmt.Sprintf("%s/%s.csv", basePathBins, nameFileBins)
	pathCsvFileWithoutBin := fmt.Sprintf("%s/%s-withouth-bins.csv", basePathBins, nameFileBins)

	fileToParamsSorted, err := os.Open(pathCsvFileParamsSorted)
	if err != nil {
		panic("Can not read fileToSave: " + pathCsvFileParamsSorted)
	}

	loadArrayBinsTotal(pathCsvFileWithoutBin, fileToParamsSorted)
	loadArrayBinsNotSync()
	saveSummaryBin(basePathBins, nameFileBins)

	fmt.Println("Finish")
}

func saveSummaryBin(basePath string, nameFileBase string) {
	url := basePath + nameFileBase + "-bins.csv"
	file, _ := os.Create(url)
	for index := range arrayBinsNotSync {
		bin := arrayBinsNotSync[index]
		file.WriteString(bin + "\n")
	}
	file.Close()
}

func loadArrayBinsNotSync() {
	total := len(arrayBins)
	mapBinNotSync := make(map[string]bool)
	fmt.Println("\nTotal bins: ", total)

	client := &http.Client{}

	velocityRPSCallerId := 60000 / 2000
	limiterCallerID := time.Tick(time.Duration(velocityRPSCallerId) * time.Millisecond)

	var wg sync.WaitGroup

	for index := range arrayBins {
		<-limiterCallerID
		wg.Add(1)
		fmt.Printf("\033[2K\rChecking: %d/%d", index, total)
		go func() {
			defer wg.Done()
			bin := arrayBins[index]
			urlBinGet := fmt.Sprintf(urlBin, bin, "MLB")
			request, _ := http.NewRequest(http.MethodGet, urlBinGet, nil)
			request.Header.Set("X-Auth-Token", xAuthTokenBins)

			resp, err := client.Do(request)
			if err != nil {
				panic(err)
			}

			if resp.StatusCode == http.StatusNotFound {
				mapBinNotSync[bin] = true
			}

			resp.Body.Close()
		}()
	}
	wg.Wait()

	for k, _ := range mapBinNotSync {
		arrayBinsNotSync = append(arrayBinsNotSync, k)
	}

	fmt.Println("\nmapBinNotSync: ", len(mapBinNotSync))
}

func loadArrayBinsTotal(pathPatternWithoutCallerId string, pFile *os.File) []string {
	mapBins := make(map[string]bool)
	_, _ = pFile.Seek(0, 0)
	scanner := bufio.NewScanner(pFile)
	file, err := os.Create(pathPatternWithoutCallerId)
	if err != nil {
		panic("saveFileByBins: " + pathPatternWithoutCallerId)
	}
	defer file.Close()

	index := 0
	total := getTotalRowsBins(basePathBins + nameFileBins + ".csv")

	for scanner.Scan() {
		index++
		fmt.Printf("\033[2K\rReading: %d/%s", index, total)
		request := scanner.Text()
		urlValue, err := url.Parse(request)
		if err != nil {
			panic("saveFileByBins: " + request)
		}
		bin := urlValue.Query().Get("bins")
		if bin != "" {
			mapBins[bin] = true
		} else {
			// separar archivo sin caller id
			file.WriteString(request + "\n")
		}
	}

	for k, _ := range mapBins {
		arrayBins = append(arrayBins, k)
	}

	return arrayBins
}

func getTotalRowsBins(pathFile string) string {
	out, err := exec.Command("/bin/sh", "-c", fmt.Sprintf("wc -l %s", pathFile)).CombinedOutput()

	if err != nil {
		panic("getTotalRows - " + pathFile)
	}

	result := strings.Trim(string(out), " ")
	countTemp := strings.Split(result, " ")[0]
	count := strings.TrimSuffix(countTemp, "\n")

	return count
}
