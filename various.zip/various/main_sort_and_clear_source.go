package various

import (
	"bufio"
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"strings"
)

var (
	hostValue  = "http://localhost:8080"
	basePathSC = "/Users/mpons/Downloads/MLA-Lote1-NONE/"
	nameFileSC = "MLA-Lote1-NONE"
)

func main() {
	arrayParametersToRemoveFromRequest := []string{"amount", "attributes"}
	pathCsvFile := fmt.Sprintf("%s/%s.csv", basePathSC, nameFileSC)
	pathCsvFileFiltered := fmt.Sprintf("%s/%s-filtered.csv", basePathSC, nameFileSC)
	pathCsvFileSource := fmt.Sprintf("%s/%s-source.csv", basePathSC, nameFileSC)

	fileToRead, err := os.Open(pathCsvFile)
	if err != nil {
		panic("Can not read fileToRead: " + pathCsvFile)
	}
	fileToParamsFiltered, err := os.Create(pathCsvFileFiltered)
	if err != nil {
		panic("Can not read fileToSave: " + pathCsvFileFiltered)
	}

	totalLine := getTotalRowsInFile(pathCsvFile)
	fmt.Println(fmt.Sprintf("File %s: %s requests", nameFileSC, totalLine))

	saveFileParamsSorted(fileToRead, fileToParamsFiltered, &arrayParametersToRemoveFromRequest)
	fileToRead.Close()
	fileToParamsFiltered.Close()

	removeDuplicatedLines(pathCsvFileFiltered, pathCsvFileSource)
	totalLine = getTotalRowsInFile(pathCsvFileSource)
	fmt.Println("File saved (sorted by params, uniq lines): ", totalLine, " requests")

	err = os.Remove(pathCsvFileFiltered)
	if err != nil {
		fmt.Println(err)
	}

	fmt.Println("Finish")
}

func removeDuplicatedLines(pathFileSource string, pathFileSummary string) {
	exec.Command("/bin/sh", "-c", fmt.Sprintf("sort %s | uniq -u > %s", pathFileSource, pathFileSummary)).CombinedOutput()
}

//func metricRequestPatterns(file *os.File, pathCsvFileMetrics string) {
//	var mapRequestTotalsPattern = make(map[string]int)
//	_, _ = file.Seek(0, 0)
//	scanner := bufio.NewScanner(file)
//	for scanner.Scan() {
//		request := scanner.Text()
//		urlValue, _ := url.Parse(hostValue + request)
//		values := urlValue.Query()
//		for k, _ := range values {
//			values.Del(k)
//			values.Add(k, "1")
//		}
//		urlValue.RawQuery = values.Encode()
//		requestSorted := urlValue.Path + "?" + urlValue.Query().Encode()
//
//		count := mapRequestTotalsPattern[requestSorted]
//		count ++
//		mapRequestTotalsPattern[requestSorted] = count
//	}
//
//	fileMetric, _ := os.Create(pathCsvFileMetrics)
//	defer fileMetric.Close()
//
//
//	type kv struct {
//		Key   string
//		Value int
//	}
//
//	var ss []kv
//	for k, v := range mapRequestTotalsPattern {
//		ss = append(ss, kv{k, v})
//	}
//
//	sort.Slice(ss, func(i, j int) bool {
//		return ss[i].Value > ss[j].Value
//	})
//
//	for _, kv := range ss {
//		fileMetric.WriteString(fmt.Sprint(kv.Value , " , " , kv.Key , "\n"))
//	}
//
//}

func saveFileParamsSorted(fileToRead *os.File, fileToWrite *os.File, arrayParametersToRemoveFromRequest *[]string) {
	_, _ = fileToRead.Seek(0, 0)
	scanner := bufio.NewScanner(fileToRead)
	for scanner.Scan() {
		request := scanner.Text()
		request = strings.Replace(request, "/batch/", "/", -1)
		request = strings.Replace(request, "/admin/", "/", -1)
		requestSorted := sortAndRemoveRequestParams(request, *arrayParametersToRemoveFromRequest)
		if requestSorted != "" {
			fileToWrite.WriteString(requestSorted + "\n")
		}
	}
}

func sortAndRemoveRequestParams(request string, arrayParametersToRemoveFromRequest []string) string {
	var requestSorted string
	if !strings.Contains(request, "request_uri") {
		urlValue, err := url.Parse(request)
		if err != nil {
			panic("sortAndRemoveRequestParams: " + request)
		}

		values := urlValue.Query()
		for k, _ := range values {
			for index := range arrayParametersToRemoveFromRequest {
				keyToDelete := arrayParametersToRemoveFromRequest[index]
				if k == keyToDelete {
					values.Del(k)
					break
				}
			}
			urlValue.RawQuery = values.Encode()
		}

		requestSorted = urlValue.Path + "?" + urlValue.Query().Encode()
		//fmt.Println(urlValue.Path + "/" + requestSorted)
	}
	return requestSorted
}

func getTotalRowsInFile(pathFile string) string {
	out, err := exec.Command("/bin/sh", "-c", fmt.Sprintf("wc -l %s", pathFile)).CombinedOutput()

	if err != nil {
		panic("getTotalRowsInFile - " + pathFile)
	}

	result := strings.Trim(string(out), " ")
	countTemp := strings.Split(result, " ")[0]
	count := strings.TrimSuffix(countTemp, "\n")

	return count
}
