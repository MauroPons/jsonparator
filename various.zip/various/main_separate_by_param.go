package various

import (
	"bufio"
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"sort"
	"strconv"
	"strings"
)

var (
	basePathParam       = "/Users/mpons/Documents/comparator/payment-methods/v2/MLB/MLB-POINT-WEEK-25to31/"
	nameFileParam       = "MLB-POINT-25to31"
	csvFile             = fmt.Sprintf("%s/%s.csv", basePathParam, nameFileParam)
	param               = "bins"
	pathParamDirectory  = fmt.Sprintf("%s/%s", basePathParam, param)
	pathParamSummary    = fmt.Sprintf("%s/summary.csv", pathParamDirectory)
	mapFilesWithParam   = make(map[string]*os.File)
	mapCountFileByParam = make(map[string]int)
)

func main() {
	if _, err := os.Stat(pathParamDirectory); os.IsNotExist(err) {
		os.Mkdir(pathParamDirectory, 0777)
	}
	saveFileByParams()
	loadMapCountFileByParam()

	arrayParams := make([]string, 0, len(mapCountFileByParam))
	for name := range mapCountFileByParam {
		arrayParams = append(arrayParams, name)
	}

	sort.Slice(arrayParams, func(i, j int) bool {
		return mapCountFileByParam[arrayParams[i]] > mapCountFileByParam[arrayParams[j]]
	})

	fileSummary, err := os.Create(pathParamSummary)
	if err != nil {
		panic("summary")
	}

	for _, name := range arrayParams {
		msg := fmt.Sprintf("bin: %d - %s", mapCountFileByParam[name], name)
		fileSummary.WriteString(msg + "\n")
		fmt.Println(msg)
	}
	fileSummary.Close()

	fmt.Println("Finish")
}

func loadMapCountFileByParam() {
	for paramKey, file := range mapFilesWithParam {
		total := getTotalRowsByParams(file.Name())
		totalCount, _ := strconv.Atoi(total)
		mapCountFileByParam[paramKey] = totalCount
	}
}

func saveFileByParams() {
	fileCsv, _ := os.Open(csvFile)
	_, _ = fileCsv.Seek(0, 0)
	scanner := bufio.NewScanner(fileCsv)

	for scanner.Scan() {
		request := scanner.Text()
		urlValue, err := url.Parse(request)
		if err != nil {
			panic("saveFileByParams: " + request)
		}
		paramTemp := urlValue.Query().Get(param)
		if paramTemp != "" {
			fileTemp := mapFilesWithParam[paramTemp]
			if fileTemp == nil {
				fileParamPath := fmt.Sprintf("%s/%s.csv", pathParamDirectory, paramTemp)
				fileTemp, err = os.Create(fileParamPath)
				if err != nil {
					fmt.Println("saveFileByParams 2: " + paramTemp + " - " + request)
				}
			}
			if fileTemp != nil {
				fileTemp.WriteString(request + "\n")
				mapFilesWithParam[paramTemp] = fileTemp
			}
		}
	}
}

func getTotalRowsByParams(pathFile string) string {
	out, err := exec.Command("/bin/sh", "-c", fmt.Sprintf("wc -l %s", pathFile)).CombinedOutput()

	if err != nil {
		panic("getTotalRows - " + pathFile)
	}

	result := strings.Trim(string(out), " ")
	countTemp := strings.Split(result, " ")[0]

	return countTemp
}
