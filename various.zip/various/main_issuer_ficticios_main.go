package various

import (
	"bufio"
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
)

const (
	xAuthToken                 = "5b9533c68090afc582ca476f211e797cd97f7d0a0570b5c94cf8fd0c6c293261"
	pathCsvIssuerFictional     = "/Users/mpons/Downloads/isssuer-ficticios-update_Casos-OK.csv"
	urlToUpdateIssuerFictional = "https://delta_payment-methods.furyapps.io/v1/issuers/%s?caller.scopes=admin&caller.id=999999"
	jsonBodyIssuerFictional    = `{"root_issuer":%s}`
)

func main() {
	client := &http.Client{}

	csvFileIssuerFictional, err := os.Open(pathCsvIssuerFictional)
	if err != nil {
		panic("csvFileIssuerFictional: " + pathCsvIssuerFictional)
	}
	scanner := bufio.NewScanner(csvFileIssuerFictional)

	for scanner.Scan() {
		issuerFictionalLine := scanner.Text()
		if issuerFictionalLine != "issuer,root_issuer" {
			issuerFictionalSplit := strings.Split(issuerFictionalLine, ",")
			issuer := issuerFictionalSplit[0]
			rootIssuer := issuerFictionalSplit[0]

			if issuer == "" || rootIssuer == "" {
				fmt.Println("Error: issuer and root_issuer are required:", issuerFictionalLine)
			}

			var url = fmt.Sprintf(urlToUpdateIssuerFictional, issuer)
			var jsonBody = []byte(fmt.Sprintf(jsonBodyIssuerFictional, rootIssuer))

			request, _ := http.NewRequest(http.MethodPut, url, bytes.NewBuffer(jsonBody))
			request.Header.Set("Content-Type", "application/json")
			request.Header.Set("X-Auth-Token", xAuthToken)

			resp, err := client.Do(request)
			if err != nil {
				panic(err)
			}

			body, _ := ioutil.ReadAll(resp.Body)
			fmt.Println(resp.StatusCode, " - ", issuerFictionalSplit, " - response:", string(body))

			resp.Body.Close()
		}
	}
}
