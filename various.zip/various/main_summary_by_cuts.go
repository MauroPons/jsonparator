package various

import (
	"fmt"
	"os/exec"
	"strconv"
	"strings"
)

const (
	onlinePayments = "online-payments"
	instore        = "instore"
	point          = "point"
	folder         = "1_error_MLB-POINT-25to31-20210306011247"
)

func main() {
	xCallerScope := point
	basicPath := "/Users/mpons/Downloads"
	csvFullFileName := "MLB-POINT-25to31"
	csvErrorFileName := "1_error_MLB-POINT-25to31"

	csvFullFilePath := fmt.Sprintf("%s/%s.csv", basicPath, csvFullFileName)
	csvErrorFilePath := fmt.Sprintf("%s/%s/%s/%s.csv", basicPath, xCallerScope, folder, csvErrorFileName)
	csvNameErrorFilePath := fmt.Sprintf("%s/%s/%s", basicPath, xCallerScope, folder)

	fmt.Println("Init")

	logMetricByCallerScope(csvFullFilePath, csvErrorFilePath, xCallerScope, csvFullFileName)
	logMetricByStringPattern(csvFullFilePath, "marketplace=MELI", csvErrorFilePath, xCallerScope, csvFullFileName, fmt.Sprintf("%s/_%s.csv", csvNameErrorFilePath, "meli"))
	logMetricByStringPattern(csvFullFilePath, "marketplace=NONE", csvErrorFilePath, xCallerScope, csvFullFileName, fmt.Sprintf("%s/_%s.csv", csvNameErrorFilePath, "none"))
	logMetricByStringPattern(csvFullFilePath, "paypal", csvErrorFilePath, xCallerScope, csvFullFileName, fmt.Sprintf("%s/_%s.csv", csvNameErrorFilePath, "paypal"))
	logMetricByStringPattern(csvFullFilePath, "bins", csvErrorFilePath, xCallerScope, csvFullFileName, fmt.Sprintf("%s/_%s.csv", csvNameErrorFilePath, "bins"))

}

func logMetricByStringPattern(csvFullFilePath string, pattern string, csvErrorFilePath string, xCallerScope string, csvFullFileName string, nameFile string) {
	countTotal := getTotalStringPattern(csvFullFilePath, pattern, nameFile)
	countError := getTotalStringPattern(csvErrorFilePath, pattern, nameFile)
	countTotalInt, _ := strconv.Atoi(countTotal)
	countErrorInt, _ := strconv.Atoi(countError)
	okPercentage, errorPercentage := getPercentValuesTemp(countTotalInt, countErrorInt)
	fmt.Printf("%s - %s - %s.csv - %s - %s%% match, %s%% error (%s/%s)\n", xCallerScope, folder, csvFullFileName, pattern, okPercentage, errorPercentage, countError, countTotal)
}

func getTotalStringPattern(pathFile string, pattern string, nameFile string) string {
	//grep -ow 'marketplace=MELI' MLB-202101_04_10-ERROR.csv | wc -l
	cmd := fmt.Sprintf("grep -ow '%s' '%s' | wc -l", pattern, pathFile)
	out, err := exec.Command("/bin/sh", "-c", cmd).CombinedOutput()

	if err != nil {
		panic("getTotalStringPattern - " + pathFile + " - " + pattern)
	}

	result := strings.Trim(string(out), " ")
	countTemp := strings.Split(result, " ")[0]
	count := strings.TrimSuffix(countTemp, "\n")

	cmd2 := fmt.Sprintf("grep '%s' %s > %s", pattern, pathFile, nameFile)
	exec.Command("/bin/sh", "-c", cmd2).CombinedOutput()

	return count
}

func logMetricByCallerScope(csvFullFilePath string, csvErrorFilePath string, xCallerScope string, csvFullFileName string) {
	totalLineFileFull := getTotalLineFile(csvFullFilePath)
	totalLineFileError := getTotalLineFile(csvErrorFilePath)
	fullLinesInt, _ := strconv.Atoi(totalLineFileFull)
	errorLinesInt, _ := strconv.Atoi(totalLineFileError)
	okPercentage, errorPercentage := getPercentValuesTemp(fullLinesInt, errorLinesInt)
	fmt.Printf("%s - %s - %s.csv - total - %s%% match, %s%% error (%s/%s)\n", xCallerScope, folder, csvFullFileName, okPercentage, errorPercentage, totalLineFileError, totalLineFileFull)
}

func getPercentValuesTemp(total int, error int) (string, string) {
	match := total - error
	percentMatch := float64(0)
	percentError := float64(0)
	if total != 0 {
		percentMatch = float64(match) * 100 / float64(total)
		percentError = float64(error) * 100 / float64(total)
	}
	return fmt.Sprintf("%.2f", percentMatch), fmt.Sprintf("%.2f", percentError)
}

func getTotalLineFile(pathFile string) string {
	out, err := exec.Command("wc", "-l", pathFile).CombinedOutput()

	if err != nil {
		panic("getTotalLineFile - " + pathFile + " - ")
	}

	result := strings.Trim(string(out), " ")
	count := strings.Split(result, " ")[0]

	return count
}
