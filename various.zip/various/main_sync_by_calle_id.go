package various

import (
	"bufio"
	"bytes"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"sort"
	"sync"
	"time"
)

var (
	//basePathSync = "/Users/mpons/Downloads/point/1_error_MLB-POINT-25to31-20210306011247/"
	//initLimit = 385466
	//nameFileSync = "1_error_MLB-POINT-25to31"

	basePathSync = "/Users/mpons/Downloads/1M-2M/"
	initLimit    = 25629
	nameFileSync = "results"

	arrayCallerIdSync      []string
	xAuthTokenCallerIDSync = "54e476dc436f8ae841fca1abdf5f07f03241b5610f9b5c0857726d9db0d4cc38"
	rpm                    = 3000
)

func main() {
	pathCsvFileParamsSorted := fmt.Sprintf("%s/%s.csv", basePathSync, nameFileSync)

	fileToParamsSorted, err := os.Open(pathCsvFileParamsSorted)
	if err != nil {
		panic("Can not read fileToSave: " + pathCsvFileParamsSorted)
	}

	syncByCallerId(fileToParamsSorted)
	fmt.Println("\nFinish")
}

func syncByCallerId(pFile *os.File) {

	mapCallerId := make(map[string]bool)
	_, _ = pFile.Seek(0, 0)
	scanner := bufio.NewScanner(pFile)

	for scanner.Scan() {
		request := scanner.Text()
		urlValue, err := url.Parse(request)
		if err != nil {
			panic("syncByCallerId: " + request)
		}
		callerId := urlValue.Query().Get("caller.id")
		if callerId != "" {
			mapCallerId[callerId] = true
		}
	}

	keys := make([]string, 0, len(mapCallerId))
	for k := range mapCallerId {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	client := &http.Client{}
	jsonBody := `{"msg": {"site_id":"MLB", "seller_id":%s}}`
	url := "https://testing-synchronizer-contingency_payment-methods-read-v2.furyapps.io/v2/payment-methods/refresh"

	velocityRPSCallerId := 60000 / rpm
	limiterCallerID := time.Tick(time.Duration(velocityRPSCallerId) * time.Millisecond)

	var wg sync.WaitGroup

	totalMapCallerId := len(mapCallerId)

	for index := range keys {
		if index > initLimit {
			<-limiterCallerID
			index++
			wg.Add(1)
			fmt.Printf("\033[2K\r%d/%d", index, totalMapCallerId)
			go func() {
				defer wg.Done()
				callerId := keys[index]
				jsonBodyCallerId := []byte(fmt.Sprintf(jsonBody, callerId))
				request, _ := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(jsonBodyCallerId))
				request.Header.Set("Content-Type", "application/json")
				request.Header.Set("X-Auth-Token", xAuthTokenCallerIDSync)
				request.Header.Set("X-Caller-Scopes", "admin,point")

				resp, err := client.Do(request)
				if err != nil {
					panic(err)
				}

				//body, _ := ioutil.ReadAll(resp.Body)
				//fmt.Println(resp.StatusCode, " - ", callerId, " - response:", string(body))

				if resp.StatusCode == 401 {
					panic("Update X-Auth-Token")
				}

				resp.Body.Close()
			}()
		}
	}
}
